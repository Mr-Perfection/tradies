(function() {
  jQuery(function() {
    return $('.chosen-it').chosen();
  });

}).call(this);
